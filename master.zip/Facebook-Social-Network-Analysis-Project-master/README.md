# Facebook-Social-Network-Analysis-Project

Files required for the Facebook Social Network Analysis Project :

  - Edges List
  - Attributes List
